from flasgger import Swagger

from lib.app import app
from config.config import SWAGGER_CONFIG
from config.config import SWAGGER_TEMPLATE

def setup_swagger():
    return Swagger(app, config=SWAGGER_CONFIG, merge=True, template=SWAGGER_TEMPLATE)