from flask import Flask

app = Flask('flask-sql-demo')