from flask import Blueprint
from lib.db import db
from lib.auth import token_auth
from flasgger import swag_from

main = Blueprint('main', __name__)

@main.route('/')
def index():
    return 'Index'

@main.route('/profile')
@token_auth.login_required
@swag_from('../../docs/profile.yml')
def profile():
    return 'Profile'