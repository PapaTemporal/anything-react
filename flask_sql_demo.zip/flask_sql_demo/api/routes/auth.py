import json
import time
from flask import Blueprint
from flask import request
from flask import url_for
from flask import g
from flask import Response
from flasgger import swag_from

from lib.db import db
from lib.auth import basic_auth
from api.models.user import User


auth = Blueprint('auth', __name__)

@auth.route('/signup', methods=['POST'])
@swag_from('../../docs/signup.yml')
def signup():
    username = request.json.get('username')
    password = request.json.get('password')

    if username is None or password is None:
        return Response(json.dumps({'STATUS': 'ERROR', 'MESSAGE': 'Missing username or password.'}), status=400, mimetype='application/json')

    if User.query.filter_by(username=username).first() is not None:
        return Response(json.dumps({'STATUS': 'ERROR', 'MESSAGE': 'Username already exists.'}), status=409, mimetype='application/json')

    new_user = User(username=username)
    new_user.hash_password(password)

    db.session.add(new_user)
    db.session.commit()

    return Response(json.dumps({'id': new_user.id, 'username': username}), status=201, mimetype='application/json')

@auth.route('/token')
@basic_auth.login_required
@swag_from('../../docs/token.yml')
def get_token():
    token = g.user.generate_auth_token(600)
    return Response(json.dumps({'access_token': token, 'expires': time.time() + 600}), status=200, mimetype='application/json')
