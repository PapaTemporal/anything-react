import time
import jwt
from werkzeug.security import generate_password_hash
from werkzeug.security import check_password_hash
from flask import g

from lib.db import db
from config.config import SECRET_KEY
from lib.auth import basic_auth
from lib.auth import token_auth


class User(db.Model):
    __bind_key__ = 'users'
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(32), index=True, unique=True)
    password_hash = db.Column(db.String(128))

    def hash_password(self, password):
        self.password_hash = generate_password_hash(password, method='sha256')

    def verify_password(self, password):
        return check_password_hash(self.password_hash, password)

    def generate_auth_token(self, expires_in=600):
        return jwt.encode(
            {'id': self.id, 'exp': time.time() + expires_in},
            SECRET_KEY, algorithm='HS256'
        )

    @staticmethod
    def verify_auth_token(token):
        try:
            data = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])
        except:
            return
        return User.query.get(data['id'])


@basic_auth.verify_password
def verify_password(username, password):
    user = User.query.filter_by(username=username).first()
    if not user or not user.verify_password(password):
        return False
    g.user = user
    return True

@token_auth.verify_token
def verify_token(token):
    user = User.verify_auth_token(token)

    if not user:
        return False
    g.user = user
    return True
