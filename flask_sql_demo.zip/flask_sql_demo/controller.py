import os

from config.config import SECRET_KEY
from config.config import SQLALCHEMY_DATABASES
from lib.app import app
from lib.db import db
from lib.swagger import setup_swagger
from api.routes.auth import auth as auth_blueprint
from api.routes.main import main as main_blueprint


def create_app():
    app.config['SECRET_KEY'] = SECRET_KEY
    app.config['SQLALCHEMY_BINDS'] = SQLALCHEMY_DATABASES
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    db.init_app(app)
    if not os.path.exists('registered'):
        with app.app_context():
            db.create_all()
        open('registered', 'w').close()

    # Attach blueprints here ...
    app.register_blueprint(auth_blueprint, url_prefix='/auth')
    app.register_blueprint(main_blueprint, url_prefix='/api')

    setup_swagger()

    return app


if __name__ == '__main__':
    app = create_app()
    app.run(host='0.0.0.0', port=8080, debug=True)