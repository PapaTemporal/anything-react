import os

PROFILE = os.getenv('PROFILE', 'LOCAL')

BASE_PATH = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))

SWAGGER_CONFIG = {'specs_route': '/swagger/'}
SWAGGER_TEMPLATE = {
    'info': {
        'title': 'Flask SQL Demo API',
        'description': 'Simple API with user creation -> token request -> access with token flow.',
        'contact': {
            'responsibleOrganization': 'METHUSELA',
            'responsibleDeveloper': 'Some Guy',
            'email': 'never@foryou.com',
            'url': 'www.google.com'
        }
    }
}

SQLALCHEMY_DATABASES = {
    'users': f'sqlite:///{os.path.join(BASE_PATH, "users.db")}',
}

SECRET_KEY = 'MYSUPERSECRETKEYTHATNOONECANCRACK'
